import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
import os
from sklearn.model_selection import train_test_split
import torch
import flask
from flask import Flask, jsonify, request



#app = Flask(__name__,static_folder='.', template_folder='.') # '.' means the current directory else it looks for 'templates' folder to render any html template.

app = Flask(__name__)



def padding(grp):
    '''
    Input to lstm or transformers model should be fixed and same.
    Max data among all students contains 144 rows. 
    Every other student-video data which doesn't have 144 rows will be padded with 0's
    '''
    grp = grp.drop(['SubjectID', 'VideoID','predefinedlabel', 'user-definedlabeln'], axis=1)
    max_length = 144
    grp_length = grp.shape[0] # number of rows for this student-video data
    padding_list = [0]* grp.shape[1] # [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    num_padding_rows = max_length - grp_length 
    padding_array = pd.DataFrame([padding_list]*num_padding_rows, columns=grp.columns)
    grp = pd.concat([grp,padding_array], axis=0, ignore_index=True)
    return grp.values# return numpy array

def transformer_model():
    '''Transformer model architecture
    Only one encoder layer is selected instead of stacked encoders to keep model simple as data size is small
    Followed by flatten, dense, dropout for regularization and sigmoid layer for binary classifiaction problem
    '''
    
    model = torch.nn.Sequential(
         torch.nn.TransformerEncoderLayer(d_model=17, nhead=1),
         torch.nn.Flatten(start_dim = 1), # start from axis 1 i.e 144 so 144*17= 2448
         torch.nn.Linear(2448,1), # Dense layer 
         torch.nn.Dropout(p=0.2),
         torch.nn.Sigmoid(),
        )
    
    return model


@app.route('/')
def hello_world():
    return 'uh-ooh it seems you have reached wrong place. Add /index to your url to land at Confusion Prediction page.'


@app.route('/index', methods=['GET'])
def index():
    '''Front-page of web application'''
    return flask.render_template('cs2_index.html')



@app.route('/predict', methods = ['GET', 'POST'])    
def predict():
    ''' When user submits input data, process it
        and trained model makes prediction on user's mindstate -
        confused or not
    '''
    if request.method == 'POST':
        data_file = request.files['file']
        test_data = pd.read_csv(data_file.filename)
        test_data = pd.get_dummies(test_data)
        test_data_padded = padding(test_data)
        test_data_padded = np.asarray(test_data_padded).astype('float32')
        
        # Converting numpy array to torch tensor
        test_tensor = torch.Tensor(test_data_padded)
        ## Load pre-trained model for prediction
        loaded_model_dict = torch.load('model.pt',map_location=torch.device('cpu'))
        model_archi = transformer_model()

        model_archi.load_state_dict(loaded_model_dict )
        
        ypred = model_archi(torch.reshape(test_tensor,(1,144,17)))
        
        if ypred>0.5:            
            return flask.render_template('Confused.html')
        else:
            return flask.render_template('Not_confused.html')
    

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
